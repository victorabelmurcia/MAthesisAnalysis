# Aangepast op 05 februari 2009
"search.extended" <-
function(verbose){
  cat("Sorry not available yet",fill=T)
}
